import json, subprocess, sys
from pathlib import Path
run = Path(sys.argv[1])
base = 'https://onderwijsboeking.geofort.nl'
cookie = run/'survey-http-cookie'
def request(path, expected, body=None, token=None):
    args=['curl','--disable','--noproxy','*','--silent','--show-error','--max-time','20','--resolve','onderwijsboeking.geofort.nl:443:127.0.0.1','--cookie-jar',str(cookie),'--cookie',str(cookie),'-w','\n%{http_code}',base+path]
    if body is not None:
        args += ['-H','Content-Type: application/json','--data-binary',json.dumps(body)]
    if token is not None:
        args += ['-H','X-CSRF-Token: '+token]
    result=subprocess.run(args,check=True,capture_output=True,text=True,timeout=30).stdout
    content, code=result.rsplit('\n',1)
    if code!=str(expected): raise RuntimeError(f'{path}: expected {expected}, got {code}')
    return content
try:
    html=request('/evaluatie/',200)
    assert 'id="visit-survey"' in html and '/build/assets/survey-' in html
    public=json.loads(request('/api/visit-survey.php',200))
    assert public['ok'] and len(public['csrfToken'])>=32
    assert not json.loads(request('/api/visit-survey.php',403,{'action':'view','token':'0'*64}))['ok']
    assert not json.loads(request('/api/visit-survey.php',422,{'action':'view','token':'0'*64},public['csrfToken']))['ok']
    assert not json.loads(request('/api/admin/visit-surveys.php',401))['ok']
    (run/'survey-http-PASS').write_text('Survey page 200, CSRF GET 200, missing CSRF 403, invalid invitation 422, unauthenticated admin 401. No answers or mail.\n')
    print('SURVEY HTTP PASS - compiled page, public session/CSRF, invalid invitation and dashboard authentication; no writes or mail')
finally:
    cookie.unlink(missing_ok=True)
