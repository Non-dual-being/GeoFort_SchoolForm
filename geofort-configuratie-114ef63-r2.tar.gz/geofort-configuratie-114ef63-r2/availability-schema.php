<?php
declare(strict_types=1);
ini_set('zend.exception_ignore_args', '1');

function configureAvailabilitySchema(PDO $pdo, string $mode, string $root, string $run): void
{
    if (!in_array($mode, ['migrate', 'check'], true)) throw new RuntimeException('Invalid schema operation');
    $tables = ['booking_program_schedule','booking_program_access_history'];
    $existing = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    $present = array_values(array_intersect($tables, $existing));
    $access = $pdo->query('SELECT * FROM booking_program_access ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
    if (count($access) !== 1 || (int)$access[0]['id'] !== 1) throw new RuntimeException('Existing program access setting missing or ambiguous');
    if ($mode === 'migrate') {
        if (!is_file($run.'/data-backed-up')) throw new RuntimeException('A private backup is required first');
        if ($present && !is_file($run.'/availability-migration-started')) throw new RuntimeException('Availability tables already exist outside this release; inspect, never overwrite');
        $sql = file_get_contents($root.'/database/sql/2026-11-02_create_program_availability.sql');
        $sql = preg_replace('/^--[^\n]*$/m', '', $sql);
        $statements = array_values(array_filter(array_map('trim', explode(';', $sql))));
        if (count($statements) !== 3
            || !str_starts_with($statements[0], 'CREATE TABLE booking_program_schedule (')
            || $statements[1] !== "INSERT INTO booking_program_schedule (id, periods_json) VALUES (1, '[]')"
            || !str_starts_with($statements[2], 'CREATE TABLE booking_program_access_history (')) {
            throw new RuntimeException('Unexpected additive migration');
        }
        // DDL commits implicitly. The journal permits safe resumption, never replacement.
        if (!is_file($run.'/availability-migration-started')) file_put_contents($run.'/availability-migration-started', date(DATE_ATOM));
        if (!in_array($tables[0], $present, true)) $pdo->exec($statements[0]);
        $rows = $pdo->query('SELECT id, periods_json FROM booking_program_schedule')->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows) $pdo->exec($statements[1]);
        elseif (count($rows) !== 1 || (int)$rows[0]['id'] !== 1 || $rows[0]['periods_json'] !== '[]') throw new RuntimeException('Unexpected configuration during migration; never overwrite');
        if (!in_array($tables[1], $present, true)) $pdo->exec($statements[2]);
        if ((int)$pdo->query('SELECT COUNT(*) FROM booking_program_access_history')->fetchColumn() !== 0) throw new RuntimeException('Unexpected history during preparation');
        if ($access !== $pdo->query('SELECT * FROM booking_program_access ORDER BY id')->fetchAll(PDO::FETCH_ASSOC)) throw new RuntimeException('Existing open/closed setting changed');
    }
    foreach (['booking_program_schedule'=>['id','periods_json'], 'booking_program_access_history'=>['id','revision','before_json','after_json','changed_by','created_at']] as $table=>$columns) {
        if (array_column($pdo->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_ASSOC), 'Field') !== $columns) throw new RuntimeException('Unexpected columns in '.$table);
    }
    $rows = $pdo->query('SELECT id, periods_json FROM booking_program_schedule')->fetchAll(PDO::FETCH_ASSOC);
    if (count($rows) !== 1 || (int)$rows[0]['id'] !== 1) throw new RuntimeException('Availability singleton missing');
    $periods = json_decode($rows[0]['periods_json'], true, 16, JSON_THROW_ON_ERROR);
    \GeoFort\Booking\ProgramAvailabilityPolicy::validatePeriods($periods);
    if ($mode === 'migrate' && $periods !== []) throw new RuntimeException('Local test periods must not be imported');
    echo 'AVAILABILITY SCHEMA PASS - two configuration tables; existing open/closed setting retained; '.count($periods)." configured periods\n";
}

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    [$script,$mode,$root,$run] = $argv;
    require $root.'/vendor/autoload.php';
    $env = Dotenv\Dotenv::parse(file_get_contents($root.'/.env'));
    if (($env['APP_ENV'] ?? '') !== 'production') throw new RuntimeException('Expected production environment');
    $pdo = GeoFort\Database\Connector::getConnection($env['DB_HOST'],$env['DB_NAME'],$env['DB_USER'],$env['DB_PASS']??'', $env['DB_PORT']??'3306');
    configureAvailabilitySchema($pdo,$mode,$root,$run);
}
