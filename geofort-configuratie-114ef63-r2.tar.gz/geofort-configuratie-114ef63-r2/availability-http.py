import json, subprocess
base='https://onderwijsboeking.geofort.nl'
def request(path, expected):
    result=subprocess.run(['curl','--disable','--noproxy','*','--silent','--show-error','--max-time','20','--resolve','onderwijsboeking.geofort.nl:443:127.0.0.1','-w','\n%{http_code}',base+path],check=True,text=True,capture_output=True,timeout=30).stdout
    body,code=result.rsplit('\n',1)
    if code!=str(expected): raise RuntimeError(f'{path}: expected {expected}, got {code}')
    return json.loads(body)
response=request('/api/getBookingProgramConfig.php',200)
assert response['ok'] is True
config=response['data']; availability=config['availability']
assert isinstance(availability['fiveModuleOpen'],bool) and isinstance(availability['revision'],int) and isinstance(availability['periods'],list)
assert config['fourModuleConfig']['availability']==availability
assert 'updatedAt' not in availability and all('note' not in period for period in availability['periods'])
assert not request('/api/admin/program-access.php',401)['ok']
print('AVAILABILITY HTTP PASS - public shared rules, internal notes excluded, admin authentication; no writes or mail')
