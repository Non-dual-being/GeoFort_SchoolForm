<?php
declare(strict_types=1);
ini_set('zend.exception_ignore_args', '1');
$root = $argv[1];
require $root . '/vendor/autoload.php';
use GeoFort\Booking\Stored\StoredBookingAssembler;
use GeoFort\Services\Dashboard\Roster\{RosterAutoGenerator, RosterPlanningConfig, RosterGenerationTemplateProvider, RosterPairedLessonSearch};
use GeoFort\Services\Sql\{StoredBookingSqlRepository, RosterPlanSqlRepository, RosterSessionSqlRepository};

// No connection, credentials, schema changes or stored rosters are needed.
$pdo = (new ReflectionClass(PDO::class))->newInstanceWithoutConstructor();
$config = new RosterPlanningConfig();
$templates = new RosterGenerationTemplateProvider();
$generator = new RosterAutoGenerator($pdo, new StoredBookingSqlRepository($pdo, new StoredBookingAssembler()), new RosterPlanSqlRepository($pdo), new RosterSessionSqlRepository($pdo), $config, $templates);
$search = new ReflectionMethod($generator, 'standardLessonCandidates');
$assert = static function (bool $value, string $why): void {
    if (!$value) throw new RuntimeException($why);
};
foreach ([
    [3, ['Voedsel-Innovatie', 'Klimaat-Experience', 'Dynamische-Globe', 'Earth-Watch', 'Minecraft-Programmeren'], 'dag', null],
    [4, ['Voedsel-Innovatie', 'Klimaat-Experience', 'Dynamische-Globe', 'Stop-de-Klimaat-Klok'], 'dag', 'day-four-2027'],
    [5, ['Zandtafel', 'Rising-Risk', 'Dynamische-Globe', 'Dynamische-Globe-Bios', 'Expedition-Earth'], 'ochtend', null],
] as [$count, $keys, $program, $version]) {
    $groups = array_map(static fn (int $id): array => ['id' => $id, 'label' => "Groep $id"], range(1, $count));
    $rounds = $templates->defaultRounds($program, count($keys));
    $modules = array_map(static fn (string $key): array => [...$config->moduleOption($key, $version), 'programModuleCount' => count($keys)], $keys);
    $proposals = $search->invoke($generator, $groups, $rounds, $modules, []);
    $assert($proposals !== [], 'No standard proposal found');
    $p = $proposals[0];
    $assert((new RosterPairedLessonSearch($config, true))->conflicts($p, []) === [], 'Normal capacity exceeded');
    foreach ($groups as $group) {
        $actual = [];
        foreach ($p as $session) if (in_array($group['id'], $session['groupIds'], true)) $actual[] = $session['moduleKey'];
        sort($actual); $expected = $keys; sort($expected);
        $assert($actual === $expected, 'Incorrect lesson coverage');
    }
    echo "PASS: $program, $count groups, " . count($keys) . " modules; no exceptional double lessons\n";
}

$keys = ['Voedsel-Innovatie', 'Dynamische-Globe', 'Klimaat-Experience', 'Klimparcours'];
$modules = array_map($config->moduleOption(...), $keys);
$rounds = $templates->defaultRounds('dag', 4);
foreach ([
    $keys,
    ['Voedsel-Innovatie', 'Klimparcours', 'Klimaat-Experience', 'Dynamische-Globe'],
] as $order) {
    $preferences = ['moduleOrder' => $order, 'supervision' => ['Klimaat-Experience' => 'geofort', 'Klimparcours' => 'school']];
    $p = $search->invoke($generator, [['id'=>1,'label'=>'Groep 1']], $rounds, $modules, [], false, $preferences)[0];
    $actual = [];
    foreach ($rounds as $round) foreach ($p as $session) {
        if ($session['startTime'] !== $round['startTime']) continue;
        $actual[] = $session['moduleKey'];
        if ($session['moduleKey'] === 'Klimaat-Experience') $assert(!$session['schoolFallback'] && $session['minimumGeoFortStaff'] === 1, 'GeoFort role not open');
        if ($session['moduleKey'] === 'Klimparcours') $assert($session['schoolFallback'] && $session['minimumGeoFortStaff'] === 0, 'School supervision not respected');
    }
    $assert($actual === $order, 'Ranked preferences not reflected in generated schedule');
}
echo "SMOKE PASS — all module ranks and supervision checked; no database connection made\n";

// Appended to the existing pure release smoke test; no database connection.
foreach([null,'day-four-2027'] as $version) {
    $assert($config->requiredGeoFortGuidesForSession('Voedsel-Innovatie',2,false,$version)===1,'VI must require one guide for two groups');
}
$foodRow=static fn(int $id):array=>['sessionId'=>$id,'moduleKey'=>'Voedsel-Innovatie','groupCount'=>1,'groupIds'=>[$id],
    'startTime'=>'10:15','endTime'=>'11:00','staffIds'=>[10,20],'cookStaffId'=>20];
$foodPlan=static fn(int $id):array=>['planId'=>$id,'pairId'=>99,'revision'=>1,'visitDate'=>'2028-10-10','schoolName'=>'Smoke fixture',
    'cookStaffId'=>20,'occupancy'=>[$foodRow($id)]];
$dayRules=new GeoFort\Services\Dashboard\Roster\RosterDayRules($config);
$pair=[$foodPlan(1),$foodPlan(2)];
$assert(!$dayRules->validate($pair)['validLessons'],'Different schools must never share VI at one time');
$sameSchool=$pair[0];
$sameSchool['occupancy'][]=$pair[1]['occupancy'][0];
$assert($dayRules->validate([$sameSchool])['canFinalize'],'Two groups of the same school must retain one cook and guide');
$sequential=$pair;
$sequential[1]['occupancy'][0]['startTime']='11:00';
$sequential[1]['occupancy'][0]['endTime']='11:45';
$assert($dayRules->validate($sequential)['canFinalize'],'Consecutive schools must be permitted');
$separateTeams=$pair;
$separateTeams[1]['occupancy'][0]['staffIds']=[11,21];
$separateTeams[1]['occupancy'][0]['cookStaffId']=21;
$assert(!$dayRules->validate($separateTeams)['validLessons'],'Separate staff teams do not allow different schools to share VI');
$lessonOnly=$pair;
foreach($lessonOnly as &$p) $p['occupancy'][0]['staffIds']=[];
unset($p);
$assert(!$dayRules->validate($lessonOnly)['validLessons'],'Lesson-only planning must enforce school-exclusive VI');
foreach([null,'day-four-2027'] as $version) {
    $batsModules=[$config->moduleOption('Klimparcours',$version)];
    $preferences=GeoFort\Services\Dashboard\Roster\RosterLessonPreferences::defaults($batsModules);
    $assert($preferences['supervision']['Klimparcours']==='school','Bats must default to school supervision');
    $lesson=[['moduleKey'=>'Klimparcours','groupIds'=>[1],'schoolFallback'=>false]];
    $staffPreference=new ReflectionMethod($generator,'applyBatsSupervision');
    $assert($staffPreference->invoke($generator,$lesson,$preferences)[0]['schoolFallback'],'Staffed Bats must default to School');
    $preferences['supervision']['Klimparcours']='geofort';
    $assert(!$staffPreference->invoke($generator,$lesson,$preferences)[0]['schoolFallback'],'Explicit GeoFort choice must remain possible');
}
$fixed=[['planId'=>2,'moduleKey'=>'Voedsel-Innovatie','startTime'=>'10:15','endTime'=>'11:00','groupCount'=>1]];
$keys=['Voedsel-Innovatie','Dynamische-Globe','Klimaat-Experience','Klimparcours'];
$modules=array_map($config->moduleOption(...),$keys);
$separated=$search->invoke($generator,[['id'=>1,'label'=>'Groep 1']],$templates->defaultRounds('dag',4),$modules,$fixed);
$assert($separated!==[],'Second school must get a separate VI proposal');
foreach($separated[0] as $lesson)if($lesson['moduleKey']==='Voedsel-Innovatie')$assert($lesson['startTime']>='11:00','VI still overlaps the other school');

foreach(['unlinked','three_groups','different_time','extra_guide','extra_cook','other_module'] as $case) {
    $changed=$pair;
    switch($case) {
        case 'unlinked': $changed[1]['pairId']=null; break;
        case 'three_groups': $changed[1]['occupancy'][0]['groupCount']=2; break;
        case 'different_time': $changed[1]['occupancy'][0]['startTime']='10:30'; break;
        case 'extra_guide': $changed[1]['occupancy'][0]['staffIds']=[11,20]; break;
        case 'extra_cook': $changed[1]['occupancy'][0]['cookStaffId']=21; $changed[1]['occupancy'][0]['staffIds']=[10,21]; break;
        case 'other_module': foreach($changed as &$p)$p['occupancy'][0]['moduleKey']='Earth-Watch'; unset($p); break;
    }
    $assert(!$dayRules->validate($changed,true)['canFinalize'],'Invalid VI exception accepted: '.$case);
}
echo "VI SMOKE PASS — one cook/guide for two same-school groups, separate times for different schools; Bats defaults checked; no database connection\n";

require $root . '/scripts/tests/FourModulePricingDomainTest.php';

require $root . '/scripts/tests/RosterWeekXlsxTest.php';
