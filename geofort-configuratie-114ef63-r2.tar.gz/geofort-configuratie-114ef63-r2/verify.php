<?php
declare(strict_types=1);
ini_set('zend.exception_ignore_args', '1');
[$script, $mode, $root, $package] = $argv;
$metadata = json_decode(file_get_contents($package . '/metadata.json'), true, 512, JSON_THROW_ON_ERROR);
if ($mode === 'assets') {
    $manifest = json_decode(file_get_contents($root . '/public/build/.vite/manifest.json'), true, 512, JSON_THROW_ON_ERROR);
    foreach (array_keys($manifest) as $entry) {
        if (!isset($manifest[$entry])) continue;
        foreach ([$manifest[$entry]['file'], ...($manifest[$entry]['css'] ?? [])] as $asset) echo 'build/' . $asset . "\n";
    }
    exit;
}
if (!in_array($mode, ['before', 'after'], true)) throw new RuntimeException('Unknown verification mode');
foreach ($metadata['sourceFiles'] as $file => $hashes) {
    if (!preg_match('~^(?:bootstrap\.php|vite\.config\.ts|package\.json|(?:src|resources/(?:js|css)|scripts/tests|scripts/deployment|database/sql|public/api|public/booking|public/evaluatie|templates)/[A-Za-z0-9_./-]+|scripts/send-visit-surveys\.php)$~', $file) || str_contains($file, '..')) throw new RuntimeException('Unexpected source path');
    $path = $root . '/' . $file;
    $expected = $hashes[$mode];
    if ($expected === null) {
        if (file_exists($path)) throw new RuntimeException("Unexpected existing file: $file");
        continue;
    }
    if (!is_file($path) || hash('sha256', str_replace("\r\n", "\n", file_get_contents($path))) !== $expected) throw new RuntimeException("Source differs: $file");
}
if ($mode === 'after') {
    foreach ($metadata['buildFiles'] as $file => $hash) {
        if (!str_starts_with($file, 'public/build/') || str_contains($file, '..')) throw new RuntimeException('Unexpected build path');
        if (!is_file($root . '/' . $file) || hash_file('sha256', $root . '/' . $file) !== $hash) throw new RuntimeException("Build differs: $file");
    }
}
echo "File verification $mode PASS\n";
