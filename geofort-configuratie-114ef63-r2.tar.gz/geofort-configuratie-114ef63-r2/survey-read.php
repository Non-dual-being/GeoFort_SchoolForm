<?php
declare(strict_types=1);
ini_set('zend.exception_ignore_args','1');
$container=require $argv[1].'/bootstrap.php';
$pdo=$container['db'][GeoFort\Database\Connector::class];
$pdo->exec('SET SESSION TRANSACTION READ ONLY');
$service=$container['survey'][GeoFort\Services\Survey\VisitSurveyService::class];
foreach(['all','day-four','day-five','morning'] as $variant) {
    $report=$service->report(['variant'=>$variant],new DateTimeImmutable('now',new DateTimeZone('Europe/Amsterdam')));
    if($report['settings']['enabled']!==false||$report['settings']['startDate']!==null)throw new RuntimeException('Unexpected live survey report');
}
echo "SURVEY READ PASS - dashboard filters load; automatic sending OFF; existing invitations and responses retained; no mail\n";
