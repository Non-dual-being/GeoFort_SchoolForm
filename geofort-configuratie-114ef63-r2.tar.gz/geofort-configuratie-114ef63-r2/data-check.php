<?php
declare(strict_types=1);
ini_set('zend.exception_ignore_args','1');
[$script,$mode,$root,$run]=$argv;
if (!in_array($mode,['backup','check'],true)) throw new RuntimeException('Unknown mode');
require $root.'/vendor/autoload.php';
$env=Dotenv\Dotenv::parse(file_get_contents($root.'/.env'));
$pdo=GeoFort\Database\Connector::getConnection($env['DB_HOST'],$env['DB_NAME'],$env['DB_USER'],$env['DB_PASS']??'',$env['DB_PORT']??'3306');
$pdo->exec('SET SESSION TRANSACTION READ ONLY');
$names=array_values(array_filter($pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN),
    static fn(string $name):bool=>preg_match('/^(roster_[a-z0-9_]+|aanvragen|aanvraag_[a-z0-9_]+|booking_(?:change|price|rule|status)_[a-z0-9_]+|booking_program_access|visit_survey_[a-z0-9_]+)$/',$name)===1));
sort($names);
if(!in_array('roster_plans',$names,true)||!in_array('aanvragen',$names,true))throw new RuntimeException('Unexpected schema');
$result=[];
$pdo->beginTransaction();
try {
    foreach($names as $name) {
        $rows=$pdo->query("SELECT * FROM `$name`")->fetchAll(PDO::FETCH_ASSOC);
        $encoded=array_map(static fn(array $r):string=>base64_encode(serialize($r)),$rows);
        sort($encoded,SORT_STRING);
        $content=json_encode($encoded,JSON_THROW_ON_ERROR);
        if($mode==='backup') {
            $path=$run.'/data-before-'.$name.'.json.gz';
            if(file_exists($path))throw new RuntimeException('Refusing to overwrite backup');
            if(file_put_contents($path,gzencode($content,6))===false)throw new RuntimeException('Backup failed');
            chmod($path,0600);
        }
        $result[$name]=['rows'=>count($rows),'sha256'=>hash('sha256',$content)];
    }
} finally {if($pdo->inTransaction())$pdo->rollBack();}
if($mode==='backup') {
    if(file_exists($run.'/rosters-before.json'))throw new RuntimeException('Baseline already exists');
    file_put_contents($run.'/rosters-before.json',json_encode($result,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR));
    echo 'BACKUP PASS â€” '.count($result)." request/roster tables read only; private recovery copies retained\n";
} else {
    $before=json_decode(file_get_contents($run.'/rosters-before.json'),true,512,JSON_THROW_ON_ERROR);
    if($result!==$before)throw new RuntimeException('Data changed during release; investigate without overwriting user data');
    file_put_contents($run.'/rosters-after.json',json_encode($result,JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR));
    echo 'DATA PASS â€” all '.count($result)." request/roster tables unchanged; no existing booking or roster rows changed\n";
}
