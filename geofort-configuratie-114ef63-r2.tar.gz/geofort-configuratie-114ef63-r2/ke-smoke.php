<?php
declare(strict_types=1);
require $argv[1].'/vendor/autoload.php';
$config = new GeoFort\Services\Dashboard\Roster\RosterPlanningConfig();
$version = GeoFort\Booking\FourModuleProgram::VERSION;
if (!$config->requiresGeoFortForFinal('Klimaat-Experience', $version)) throw new RuntimeException('Four-module KE must block finalization without GeoFort');
if ($config->requiresGeoFortForFinal('Klimaat-Experience', null)) throw new RuntimeException('Five-module KE unexpectedly mandatory');
if ($config->requiresGeoFortForFinal('Klimparcours', $version)) throw new RuntimeException('Bats unexpectedly mandatory');
if ($config->requiredGeoFortGuidesForSession('Klimaat-Experience', 2, null, $version) !== 1) throw new RuntimeException('One guide must cover two KE groups');
if ($config->maxGroupsPerSession('Klimaat-Experience') !== 2) throw new RuntimeException('KE session must be limited to two groups');
echo "KE POLICY PASS - four modules require GeoFort, two groups per guide; no database connection\n";
