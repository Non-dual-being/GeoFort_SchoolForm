import { createRouter, createWebHashHistory } from "vue-router";
import DashboardOverviewView from "../views/DashboardOverviewView.vue";
import NotFoundView from "../views/NotFoundView.vue";
import DashboardBookingsView from "../views/DashboardBookingsView.vue";
import DashboardBookingDetailView from "../views/DashboardBookingDetailView.vue";
import DashboardCalendarView from "../views/DashboardCalendarView.vue";
import DashboardBookingExportView from "../views/DashboardBookingExportView.vue";
import DashboardBookingRevenueView from "../views/DashboardBookingRevenueView.vue";
import DashboardRostersView from "../views/DashboardRostersView.vue";
import DashboardRosterDayCreateView from "../views/DashboardRosterDayCreateView.vue";
import DashboardRosterDetailView from "../views/DashboardRosterDetailView.vue";
import DashboardRosterStaffView from "../views/DashboardRosterStaffView.vue";

export const adminRouter = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: "/", name: "overview", component: DashboardOverviewView },
    { path: "/aanvragen", name: "bookings", component: DashboardBookingsView },
    { path: "/aanvragen/:id", name: "booking-detail", component: DashboardBookingDetailView },
    { path: "/agenda", name: "calendar", component: DashboardCalendarView },
    { path: "/roosters", name: "rosters", component: DashboardRostersView },
    { path: "/roosters/nieuw", name: "roster-create", component: DashboardRosterDayCreateView },
    { path: "/roosters/personeel", name: "roster-staff", component: DashboardRosterStaffView },
    { path: "/roosters/:id", name: "roster-detail", component: DashboardRosterDetailView },
    { path: "/configuratie/ochtend", name: "morning-configuration", props: { program: "morning" }, component: () => import("../views/DashboardProgramManageView.vue") },
    { path: "/configuratie/vijf-modules", name: "five-module-configuration", props: { program: "five" }, component: () => import("../views/DashboardProgramManageView.vue") },
    { path: "/configuratie", name: "program-configuration", component: () => import("../views/DashboardProgramConfigurationView.vue") },
    { path: "/evaluaties", name: "visit-surveys", component: () => import("../views/DashboardVisitSurveysView.vue") },
    { path: "/export", name: "booking-export", component: DashboardBookingExportView },
    { path: "/omzet", name: "booking-revenue", component: DashboardBookingRevenueView },
    { path: "/personeelsinzet", name: "staff-deployment", component: () => import("../views/DashboardStaffDeploymentView.vue") },
    {
      path: "/analytics",
      name: "booking-analytics",
      component: () => import("../views/DashboardBookingAnalyticsView.vue"),
    },
    { path: "/:pathMatch(.*)*", name: "not-found", component: NotFoundView },
  ],
});
