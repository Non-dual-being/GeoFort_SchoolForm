<?php
declare(strict_types=1);
namespace GeoFort\Booking\Rules;

final class BookingRuleOverridePolicy
{
    public const PERMISSION_OVERRIDE = 'booking.rules.override';

    public function definition(string $code): BookingRuleDefinition
    {
        return match ($code) {
            'PROGRAM_NOT_OPEN' => new BookingRuleDefinition($code, BookingRuleSeverity::Error, false, null, 'Programma niet opengesteld', 'Dit programma is niet opengesteld voor deze bezoekdatum. Pas het onderwijsaanbod aan bij Configuratie of kies een andere datum of een ander programma.'),
            'INCOMPLETE_CJP_DETAILS' => $this->warning($code, 'CJP-gegevens zijn onvolledig', 'Bij deze aanvraag is aangegeven dat CJP wordt gebruikt, maar het CJP-pasnummer ontbreekt.'),
            'PROGRAM_STUDENT_LIMIT_EXCEEDED' => new BookingRuleDefinition($code, BookingRuleSeverity::Warning, false, null, 'Leerlingaantal boven de gebruikelijke programmabandbreedte', 'Dit is een planningsadvies. Ieder positief geheel leerlingaantal is toegestaan in het dashboard.'),
            'MINIMUM_SUPERVISORS_NOT_MET' => $this->warning($code, 'Er zijn minder begeleiders opgegeven dan volgens de huidige regels vereist is', 'Het opgegeven aantal begeleiders is lager dan het actuele minimum.'),
            'DISABLED_VISIT_DATE' => $this->warning($code, 'Deze bezoekdatum is geblokkeerd', 'De bezoekdatum staat in de actuele lijst met geblokkeerde datums.'),
            'SCHOOL_LIMIT_EXCEEDED' => $this->warning($code, 'Maximum aantal scholen op deze datum wordt overschreden', 'Met deze aanvraag wordt het actuele maximum aantal scholen overschreden.'),
            'STUDENT_LIMIT_EXCEEDED' => new BookingRuleDefinition($code, BookingRuleSeverity::Warning, false, null, 'Leerlingtotaal boven de gebruikelijke dagcapaciteit', 'Controleer de praktische planning. Deze leerlingwaarschuwing blokkeert de adminwijziging niet.'),
            default => new BookingRuleDefinition($code, BookingRuleSeverity::Error, false, null, 'Boekingsregel blokkeert deze wijziging', 'Deze regel kan niet worden overschreven.'),
        };
    }

    private function warning(string $code, string $title, string $description): BookingRuleDefinition
    {
        return new BookingRuleDefinition($code, BookingRuleSeverity::Warning, true, self::PERMISSION_OVERRIDE, $title, $description);
    }
}
