<?php
declare(strict_types=1);
require dirname(__DIR__,2).'/vendor/autoload.php';
require __DIR__.'/Support/DisposableBookingMariaDb.php';

use GeoFort\Booking\ProgramConfiguration\{BookingProgramConfigurationCode,BookingProgramConfigurationCommand,BookingProgramConfigurationSnapshot};
use GeoFort\Booking\BookingProgramConfig;
use GeoFort\Booking\Rules\BookingRuleOverrideRequest;
use GeoFort\Booking\Stored\{StoredBookingAssembler};
use GeoFort\Services\Booking\Data\EducationSelectionData;
use GeoFort\Services\Booking\ProgramConfiguration\BookingProgramConfigurationServiceFactory;
use GeoFort\Services\Sql\StoredBookingSqlRepository;
use GeoFort\Services\Sql\DashboardBookingDetailSqlService;
use GeoFort\Services\Dashboard\Booking\DashboardBookingDetailService;

$disposable=DisposableBookingMariaDb::create('program_configuration');$pdo=$disposable->pdo;
$checks=0;$assert=static function(bool $condition,string $message)use(&$checks):void{$checks++;if(!$condition)throw new RuntimeException($message);};$ids=[];$triggers=[];
$insert=$pdo->prepare("INSERT INTO aanvragen(status,schoolnaam,land,adres,postcode,plaats,school_telefoonnummer,contactpersoon_telefoonnummer,contactpersoon_voornaam,contactpersoon_achternaam,email,bezoekdatum,cjpPasGebruik,onderwijs_sector,programma,keuzemodule_key,aantal_leerlingen,aantal_begeleiders,remise_break,voorwaarden_akkoord) VALUES(:status,'Aggregaattest','Nederland','Dijk 1','1234 AB','Plaats','1','2','Jan','Jansen','aggregate@example.test',:date,'nee',:sector,:program,:module,:students,5,3,1)");
$selection=$pdo->prepare('INSERT INTO aanvraag_onderwijs_selecties(aanvraag_id,sector_key,sector_label,level_key,level_label,level_position,group_key,group_label,group_position) VALUES(:id,:sector,:sectorLabel,:level,:levelLabel,1,:group,:groupLabel,1)');
$make=static function(string $status,string $date,string $program='dag',?string $module='Earth-Watch',int $students=40,string $sector='primairOnderwijs',string $level='regulier',string $group='groep7')use($insert,$selection,$pdo,&$ids):int{
    $insert->execute([':status'=>$status,':date'=>$date,':sector'=>$sector,':program'=>$program,':module'=>$module,':students'=>$students]);
    $id=(int)$pdo->lastInsertId();$ids[]=$id;
    $selection->execute([':id'=>$id,':sector'=>$sector,':sectorLabel'=>BookingProgramConfig::SCHOOL_TYPES_BY_KEY[$sector]['label'],':level'=>$level,':levelLabel'=>BookingProgramConfig::SCHOOL_LEVELS[$sector][$level]['label'],':group'=>$group,':groupLabel'=>BookingProgramConfig::SCHOOL_LEVELS[$sector][$level]['groups'][$group]]);
    $stored=(new StoredBookingSqlRepository($pdo,new StoredBookingAssembler()))->findById($id)??throw new RuntimeException('Fixture ontbreekt.');
    $snapshots=(new GeoFort\Services\Booking\Pricing\BookingPriceSnapshotServiceFactory($pdo))->create();
    $pdo->beginTransaction();$snapshots->appendUsingActiveVersion($id,GeoFort\Services\Booking\Pricing\BookingPricingInput::fromStoredBooking($stored),GeoFort\Services\Booking\Pricing\BookingPriceSnapshot::REASON_SUBMISSION);$pdo->commit();return$id;
};
$repository=new StoredBookingSqlRepository($pdo,new StoredBookingAssembler());$service=(new BookingProgramConfigurationServiceFactory($pdo))->create();
$command=static function(int $id,string $program,int $students,?string $module,array $overrides=[])use($repository):BookingProgramConfigurationCommand{$booking=$repository->findById($id);$expected=BookingProgramConfigurationSnapshot::fromBooking($booking);$proposed=new BookingProgramConfigurationSnapshot($expected->status,$expected->visitDate,$program,$students,$booking->educationSelection,$module);return new BookingProgramConfigurationCommand($id,$expected,$proposed,1,$overrides);};
try{
 $access = new GeoFort\Services\Sql\BookingProgramAccessSqlRepository($pdo);
 $mondayRule = ['program'=>'morning','from'=>'2027-02-08','until'=>'2027-02-08','weekdays'=>[1],'open'=>true,'note'=>'Integration test'];
 foreach (['In optie','Definitief','Afgewezen'] as $status) {
     $id = $make($status,'2027-02-08');
     $closed = $service->change($command($id,'ochtend',40,null));
     $assert($closed->code === BookingProgramConfigurationCode::InvalidConfiguration && ($closed->issues[0]->code ?? '') === 'PROGRAM_NOT_OPEN', 'Closed Monday must require configuration, not individual override.');
     $config = $access->configuration();
     $access->saveConfiguration(true, [$mondayRule], $config['revision'], 1);
     $success = $service->change($command($id,'ochtend',40,null));
     $row = $pdo->query("SELECT status,bezoekdatum,programma,remise_break FROM aanvragen WHERE id={$id}")->fetch();
     $audit = $pdo->query("SELECT change_type FROM booking_change_history WHERE booking_id={$id}")->fetch();
     $assert($success->code === BookingProgramConfigurationCode::Success && $row['status'] === $status && $row['bezoekdatum'] === '2027-02-08' && $row['programma'] === 'ochtend' && (int)$row['remise_break'] === 3, 'Configured Monday changes unintended fields.');
     $assert($audit['change_type'] === 'program_configuration_changed' && (int)$pdo->query("SELECT COUNT(*) FROM booking_rule_overrides WHERE booking_id={$id}")->fetchColumn() === 0, 'Configured Monday must use normal audit without override.');
     $access->saveConfiguration(true, [], $access->configuration()['revision'], 1);
 }

 $wednesday=$make('In optie','2027-02-10');$assert($service->change($command($wednesday,'ochtend',40,null))->code===BookingProgramConfigurationCode::Success,'Woensdag Ochtend faalt zonder override.');$priceHistory=$pdo->query("SELECT sequence_number,snapshot_reason,pricing_version FROM booking_price_snapshots WHERE booking_id={$wednesday} ORDER BY sequence_number")->fetchAll();$assert(count($priceHistory)===2&&(int)$priceHistory[1]['sequence_number']===2&&$priceHistory[1]['snapshot_reason']==='planner_update'&&$priceHistory[1]['pricing_version']===$priceHistory[0]['pricing_version'],'Programmaconfiguratie hergebruikt historische prijsversie/sequence niet.');$morningRow=$pdo->query("SELECT programma,keuzemodule_key,status,bezoekdatum,remise_break FROM aanvragen WHERE id={$wednesday}")->fetch();$morningFields=json_decode((string)$pdo->query("SELECT changed_fields_json FROM booking_change_history WHERE booking_id={$wednesday}")->fetchColumn(),true,512,JSON_THROW_ON_ERROR);$assert($morningRow['programma']==='ochtend'&&$morningRow['keuzemodule_key']===null&&$morningRow['status']==='In optie'&&$morningRow['bezoekdatum']==='2027-02-10'&&(int)$morningRow['remise_break']===3&&($morningFields['keuzemodule_key']??null)===['before'=>'Earth-Watch','after'=>null],'Dag naar Ochtend verwijdert module niet atomair of audit ontbreekt.');
 $malicious=$make('In optie','2027-02-10');$maliciousResult=$service->change($command($malicious,'ochtend',40,'Earth-Watch'));$maliciousFields=json_decode((string)$pdo->query("SELECT changed_fields_json FROM booking_change_history WHERE booking_id={$malicious}")->fetchColumn(),true,512,JSON_THROW_ON_ERROR);$assert($maliciousResult->code===BookingProgramConfigurationCode::Success&&$pdo->query("SELECT keuzemodule_key FROM aanvragen WHERE id={$malicious}")->fetchColumn()===null&&($maliciousFields['keuzemodule_key']??null)===['before'=>'Earth-Watch','after'=>null],'Oude of kwaadaardige Ochtendpayload kan een module behouden.');
 $day=$make('In optie','2027-02-10','ochtend',null,40);$result=$service->change($command($day,'dag',80,'Earth-Watch'));$fields=json_decode((string)$pdo->query("SELECT changed_fields_json FROM booking_change_history WHERE booking_id={$day}")->fetchColumn(),true,512,JSON_THROW_ON_ERROR);$fieldKeys=array_keys($fields);sort($fieldKeys);$assert($result->code===BookingProgramConfigurationCode::Success&&$fieldKeys===['aantal_leerlingen','keuzemodule_key','programma'],'Audit bevat niet alleen werkelijk gewijzigde velden: '.implode(',',$fieldKeys));
 $educationOnly=$make('In optie','2027-02-10');$educationExpected=BookingProgramConfigurationSnapshot::fromBooking($repository->findById($educationOnly));$educationProposed=new BookingProgramConfigurationSnapshot($educationExpected->status,$educationExpected->visitDate,$educationExpected->program,$educationExpected->studentCount,new EducationSelectionData('primairOnderwijs',['regulier'],['regulier'=>['groep8']]),$educationExpected->choiceModule);$educationResult=$service->change(new BookingProgramConfigurationCommand($educationOnly,$educationExpected,$educationProposed,1));$assert($educationResult->code===BookingProgramConfigurationCode::Success&&(string)$pdo->query("SELECT group_key FROM aanvraag_onderwijs_selecties WHERE aanvraag_id={$educationOnly}")->fetchColumn()==='groep8','Onderwijsselectie-only mutatie wordt niet atomair opgeslagen.');
 foreach([[null,'MISSING_CHOICE_MODULE'],['Onbekend','INVALID_CHOICE_MODULE']] as [$invalidModule,$issueCode]){$invalidId=$make('In optie','2027-02-10');$invalidResult=$service->change($command($invalidId,'dag',80,$invalidModule));$assert($invalidResult->code===BookingProgramConfigurationCode::InvalidConfiguration&&($invalidResult->issues[0]->code??'')===$issueCode&&(string)$pdo->query("SELECT keuzemodule_key FROM aanvragen WHERE id={$invalidId}")->fetchColumn()==='Earth-Watch'&&(int)$pdo->query("SELECT COUNT(*) FROM booking_change_history WHERE booking_id={$invalidId}")->fetchColumn()===0,"{$issueCode} schrijft data of audit.");}
 $tooManyId=$make('In optie','2027-02-10');$tooManyExpected=BookingProgramConfigurationSnapshot::fromBooking($repository->findById($tooManyId));$tooManyProposed=new BookingProgramConfigurationSnapshot($tooManyExpected->status,$tooManyExpected->visitDate,'dag',80,new EducationSelectionData('primairOnderwijs',['regulier'],['regulier'=>['groep5','groep6','groep7','groep8']]),'Earth-Watch');$tooManyResult=$service->change(new BookingProgramConfigurationCommand($tooManyId,$tooManyExpected,$tooManyProposed,1));$assert(($tooManyResult->issues[0]->code??'')==='GROUP_SELECTION_LIMIT_EXCEEDED'&&(string)$pdo->query("SELECT COUNT(*) FROM aanvraag_onderwijs_selecties WHERE aanvraag_id={$tooManyId}")->fetchColumn()==='1'&&(int)$pdo->query("SELECT COUNT(*) FROM booking_change_history WHERE booking_id={$tooManyId}")->fetchColumn()===0,'Te veel groepen schrijft data of audit.');
 $conflictId=$make('In optie','2027-02-10');$stale=$command($conflictId,'ochtend',40,null);$pdo->exec("UPDATE aanvragen SET aantal_leerlingen=41 WHERE id={$conflictId}");$assert($service->change($stale)->code===BookingProgramConfigurationCode::Conflict,'Volledige expected snapshot detecteert leerlingconflict niet.');
 $rollbackId=$make('In optie','2027-02-10');$pdo->exec("CREATE TRIGGER fail_program_configuration_history BEFORE INSERT ON booking_change_history FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='forced audit failure'");$triggers[]='fail_program_configuration_history';$failed=$service->change($command($rollbackId,'ochtend',40,null));$pdo->exec('DROP TRIGGER fail_program_configuration_history');array_pop($triggers);$rollbackRow=$pdo->query("SELECT programma,keuzemodule_key FROM aanvragen WHERE id={$rollbackId}")->fetch();$assert($failed->code===BookingProgramConfigurationCode::DatabaseError&&$rollbackRow['programma']==='dag'&&$rollbackRow['keuzemodule_key']==='Earth-Watch','Auditfout rolt programma en module niet terug.');
 $snapshotRollbackId=$make('In optie','2027-02-10');$pdo->exec("CREATE TRIGGER fail_program_configuration_snapshot BEFORE INSERT ON booking_price_snapshots FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='forced snapshot failure'");$triggers[]='fail_program_configuration_snapshot';$snapshotFailed=$service->change($command($snapshotRollbackId,'ochtend',40,null));$pdo->exec('DROP TRIGGER fail_program_configuration_snapshot');array_pop($triggers);$snapshotRollbackRow=$pdo->query("SELECT programma,keuzemodule_key FROM aanvragen WHERE id={$snapshotRollbackId}")->fetch();$assert($snapshotFailed->code===BookingProgramConfigurationCode::DatabaseError&&$snapshotRollbackRow['programma']==='dag'&&$snapshotRollbackRow['keuzemodule_key']==='Earth-Watch'&&(int)$pdo->query("SELECT COUNT(*) FROM booking_price_snapshots WHERE booking_id={$snapshotRollbackId}")->fetchColumn()===1,'Snapshotfout rolt programmaconfiguratie niet terug.');
 $detailService = new DashboardBookingDetailService(new DashboardBookingDetailSqlService($pdo));
 foreach ([
     ['primairOnderwijs', 'ochtend', null, 'regulier', 'groep7'],
     ['primairOnderwijs', 'dag', 'Earth-Watch', 'regulier', 'groep7'],
     ['voortgezetOnderbouw', 'dag', 'Minecraft-Programmeren', 'havo', 'havo2'],
     ['voortgezetBovenbouw', 'dag', 'Crisismanagement', 'havo', 'havo4'],
 ] as [$sector, $program, $module, $level, $group]) {
     $label = "{$sector}/{$program}";
     $id = $make('In optie', '2026-11-04', $program, $module, 40, $sector, $level, $group);
     $detail = $detailService->getBooking($id);
     $limits = $detail['education']['configuration']['studentLimitsByProgram'];
     $assert(array_keys($limits) === ($sector === 'primairOnderwijs' ? ['ochtend', 'dag'] : ['dag']), "{$label}: dashboard biedt ongeldige sector/programmacombinaties aan.");
     foreach ($limits as $allowedProgram => $bounds) {
         $assert($bounds === ['minimum' => 1, 'maximum' => null],
             "{$label}: dashboardgrenzen zijn onjuist: " . json_encode($bounds, JSON_THROW_ON_ERROR));
     }
     foreach ([0, -1] as $invalidCount) {
         $invalid = $service->change($command($id, $program, $invalidCount, $module));
         $assert($invalid->code === BookingProgramConfigurationCode::InvalidConfiguration && ($invalid->issues[0]->code ?? '') === 'INVALID_STUDENT_COUNT'
             && $repository->findById($id)?->studentCount === 40
             && (int) $pdo->query("SELECT COUNT(*) FROM booking_change_history WHERE booking_id={$id}")->fetchColumn() === 0,
             "{$label}: ongeldige programmaconfiguratie {$invalidCount} schrijft data/historie.");
     }
     foreach ([1, 28, 39, 40] as $count) {
         $result = $service->change($command($id, $program, $count, $module));
         $assert($result->code === BookingProgramConfigurationCode::Success && $repository->findById($id)?->studentCount === $count
             && $result->issues === [], "{$label}: configuratie met {$count} leerlingen faalt: {$result->code->value}.");
     }
     $assert((int) $pdo->query("SELECT COUNT(*) FROM booking_change_history WHERE booking_id={$id}")->fetchColumn() === 4
         && (int) $pdo->query("SELECT COUNT(*) FROM booking_rule_overrides WHERE booking_id={$id}")->fetchColumn() === 0
         && (int) $pdo->query("SELECT COUNT(*) FROM booking_price_snapshots WHERE booking_id={$id}")->fetchColumn() === 5,
         "{$label}: kleine aantallen missen historie/prijssnapshots of gebruiken overrides.");
     if ($sector !== 'primairOnderwijs') {
         $invalidSector = $service->change($command($id, 'ochtend', 28, null));
         $assert($invalidSector->code === BookingProgramConfigurationCode::InvalidConfiguration && $repository->findById($id)?->program === 'dag', "{$label}: VO-ochtend is geaccepteerd.");
     }
 }
 fwrite(STDOUT,"OK: {$checks} controles voor programmaconfiguratie, kleine aantallen en dashboardgrenzen geslaagd.\n");
}finally{foreach($triggers as $trigger)$pdo->exec("DROP TRIGGER IF EXISTS {$trigger}");$disposable->drop();}
