<?php
declare(strict_types=1);
ini_set('zend.exception_ignore_args','1');
$container=require $argv[1].'/bootstrap.php';
$pdo=$container['db'][GeoFort\Database\Connector::class];
$pdo->exec('SET SESSION TRANSACTION READ ONLY');
$repo=new GeoFort\Services\Sql\BookingProgramAccessSqlRepository($pdo);
$config=$repo->configuration();
$policy=$repo->policy();
foreach(['2026-12-08','2026-12-09','2027-01-04'] as $date) {
    $policy->allows('ochtend',null,$date);
    $policy->allows('dag',null,$date);
    $policy->allows('dag',GeoFort\Booking\FourModuleProgram::VERSION,$date);
}
echo 'AVAILABILITY READ PASS - configuration revision '.$config['revision'].', '.count($config['periods'])." periods; all program variants load; no writes\n";
