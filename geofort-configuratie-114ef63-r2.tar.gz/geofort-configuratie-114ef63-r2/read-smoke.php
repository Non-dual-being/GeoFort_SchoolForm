<?php
declare(strict_types=1);
ini_set('zend.exception_ignore_args', '1');
$root=$argv[1];
$container=require $root.'/bootstrap.php';
$pdo=$container['db'][GeoFort\Database\Connector::class];
$pdo->exec('SET SESSION TRANSACTION READ ONLY');
$service=$container['dashboard'][GeoFort\Services\Dashboard\Roster\RosterPlanService::class];
$refresh=new GeoFort\Services\Dashboard\Roster\RosterBookingRefreshService(
    $pdo,$service,new GeoFort\Services\Sql\RosterPlanSqlRepository($pdo),
    new GeoFort\Services\Sql\StoredBookingSqlRepository($pdo,new GeoFort\Booking\Stored\StoredBookingAssembler()),
    new GeoFort\Services\Dashboard\Roster\RosterPlanningConfig(),
);
$records=$pdo->query('SELECT id, status FROM roster_plans ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
$checked=0; $previews=0; $protected=0; $deleted=0;
foreach($records as $record) {
    $id=(int)$record['id'];
    $plan=$service->getPlan($id);
    if($record['status']==='deleted') {
        if($plan!==null) throw new RuntimeException('Deleted roster unexpectedly visible: '.$id);
        $deleted++;
        continue;
    }
    if($plan===null) throw new RuntimeException('Existing active/archived roster missing: '.$id);
    $checked++;
    if($plan['status']!=='concept'||$plan['planningMode']!=='booking_locked')continue;
    try {
        $preview=$refresh->preview((int)$id,$plan['revision']);
        if(!is_bool($preview['canApply'])||!is_bool($preview['resetLessons'])||!is_bool($preview['clearStaffing']))throw new RuntimeException('Invalid review contract');
        if($preview['beforeSourceContext']===null&&$preview['canApply'])throw new RuntimeException('Unknown source not protected');
        $previews++;
    } catch(GeoFort\Services\Dashboard\Roster\RosterPlanException $e) {
        if(!in_array($e->publicCode,['INVALID_MODULE_CONTEXT','STUDENT_COUNT_REQUIRED'],true))throw $e;
        $protected++;
    }
}
echo "READ PASS — $checked existing rosters load, $previews read-only booking previews, $protected require source correction, $deleted deleted rosters remain hidden; no writes or mail\n";

$revenue=$container['dashboard'][GeoFort\Services\Dashboard\Booking\Revenue\BookingRevenueReportService::class];
$bounds=$revenue->availableVisitDateRange();
if (!$bounds->isEmpty()) {
    foreach(['all','day-four','day-five','morning'] as $variant) {
        $criteria=new GeoFort\Services\Dashboard\Booking\Revenue\BookingRevenueCriteria($bounds->minDate,$bounds->maxDate,'combined',programVariant:$variant);
        $report=$revenue->report($criteria,$bounds);
        $page=$revenue->page($criteria);
        if ($report->counts['bookingsTotal'] !== $page['pagination']['totalItems']) throw new RuntimeException('Revenue totals and paging disagree');
    }
}
$analytics=$container['dashboard'][GeoFort\Services\Dashboard\Booking\Analytics\BookingAnalyticsService::class];
$bounds=$analytics->bounds();
if (!$bounds->isEmpty()) {
    foreach(['all','day-four','day-five','morning'] as $variant) {
        $criteria=(new GeoFort\Services\Dashboard\Booking\Analytics\BookingAnalyticsCriteriaFactory())->create(['startDate'=>$bounds->minDate,'endDate'=>$bounds->maxDate,'programVariant'=>$variant],$bounds);
        $analytics->analyze($criteria);
    }
}
echo "REPORT READ PASS - revenue/paging and analytics for all program variants; read-only connection\n";

$weekly = new GeoFort\Services\Dashboard\Roster\RosterWeekExportService($pdo, $service);
$weeks = $weekly->weeks();
foreach ($weeks as $week) {
    $data = $weekly->export($week['key']);
    if (count($data['plans']) !== $week['rosterCount']) throw new RuntimeException('Week count mismatch');
    $file = tempnam(sys_get_temp_dir(), 'week-read-');
    try { (new GeoFort\Services\Dashboard\Roster\RosterXlsxWriter())->writeWeek($file, $data); }
    finally { unlink($file); }
}
echo 'WEEK READ PASS - ' . count($weeks) . " eligible weeks exported; no writes\n";

