Configuratie en periodehulp
Revision: 114ef633d041467bb34331ddc9b2bfda56018eaf
Expected live base: ba9e9d7a3c3a2aa1a3fdcf96bb82fe85718aba81
Prepare adds only two configuration tables, preserving the existing five-module setting.
No local test periods or local database rows are shipped. No booking, price, roster or survey writes.
Automatic survey mail remains OFF. No service/timer installation, server reboot or PHP route change.
Prepare and activate verify source hashes, compiled assets, roster/report reads and protected data hashes.
The installer refuses an unexpected live base. Never bypass that check.
Existing live vendor and shared configuration are copied; local vendor modifications are excluded.
Run during a quiet moment: concurrent booking or planner writes can correctly trigger a data check failure.
Backups and logs: /home/deploy/backups/geofort-configuratie-114ef63
Rollback retains additive tables and new data; it never restores over legitimate user changes.
The previous code does not understand the new periods. Review dates opened after rollout when rolling back.
Commands: sudo bash /tmp/geofort-configuratie-114ef63/deploy.sh prepare|activate|status|rollback
