#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
APP=/var/www/onderwijsboeking-v2
BASE=ba9e9d7a3c3a2aa1a3fdcf96bb82fe85718aba81
SHA=114ef633d041467bb34331ddc9b2bfda56018eaf
RUN=/home/deploy/backups/geofort-configuratie-114ef63
PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PHP=php8.5
die() { echo "STOP: $*" >&2; exit 1; }
[[ $EUID == 0 ]] || die 'Gebruik sudo bash deploy.sh prepare|activate|rollback|status'
command -v "$PHP" >/dev/null || die 'php8.5 ontbreekt'
exec 9>/home/deploy/.deploy-onderwijsboeking-v2.lock
flock -n 9 || die 'Er loopt al een andere uitrol'
[[ -L "$APP/current" ]] || die 'current is geen release-symlink'
CURRENT=$(readlink -f "$APP/current")
[[ "$CURRENT" == "$APP/releases/"* && -d "$CURRENT" ]] || die 'Onverwachte huidige release'

verify_package() {
  (cd "$PACKAGE" && sha256sum --quiet -c SHA256SUMS)
}
verify_env() {
  [[ "$(readlink -f "$1/.env")" == "$(readlink -f "$APP/shared/.env")" ]] || die 'De gedeelde productieconfiguratie wordt niet gebruikt'
  sha256sum --quiet -c "$RUN/env.sha256"
}
switch_to() {
  local destination=$1 holder
  [[ "$destination" == "$APP/releases/"* && -d "$destination" ]] || die 'Ongeldig releasepad'
  holder=$(mktemp -d "$APP/.switch.vi.XXXXXXXX")
  ln -s "$destination" "$holder/next"
  chown -h deploy:www-data "$holder/next"
  mv -Tf "$holder/next" "$APP/current"
  rmdir "$holder"
}
http_check() {
  local suffix=$1 path name
  for path in / /auth/login-page.php /api/getBookingProgramConfig.php; do
    name=${path//\//_}
    curl --disable --fail --silent --show-error --noproxy '*' --max-time 20 \
      --resolve onderwijsboeking.geofort.nl:443:127.0.0.1 \
      "https://onderwijsboeking.geofort.nl$path" -o "$RUN/http-$suffix-$name"
    [[ -s "$RUN/http-$suffix-$name" ]] || return 1
  done
  if [[ "$suffix" == after ]]; then
    "$PHP" "$PACKAGE/verify.php" assets "$RELEASE" "$PACKAGE" > "$RUN/assets"
    while IFS= read -r path; do
      curl --disable --fail --silent --show-error --noproxy '*' --max-time 20 \
        --resolve onderwijsboeking.geofort.nl:443:127.0.0.1 \
        "https://onderwijsboeking.geofort.nl/$path" -o "$RUN/asset-check"
      cmp "$RUN/asset-check" "$RELEASE/public/$path"
    done < "$RUN/assets"
    code=$(curl --disable --silent --show-error --noproxy '*' --max-time 20 \
      --resolve onderwijsboeking.geofort.nl:443:127.0.0.1 \
      -D "$RUN/refresh-auth-headers" -o "$RUN/refresh-auth-check" -w '%{http_code}' \
      https://onderwijsboeking.geofort.nl/api/admin/rosters/week-export.php)
    [[ "$code" == 303 ]] || return 1
    grep -iq '^location: https://onderwijsboeking.geofort.nl/auth/login-page.php' "$RUN/refresh-auth-headers" || return 1
  fi
}
assert_sending_off() {
  [[ -z "$(systemctl list-unit-files --no-legend --no-pager 'visit-surveys*')" ]] || die 'Evaluatieverzending heeft al een geinstalleerde service; controleer eerst'
  [[ -z "$(systemctl list-units --all --no-legend --plain --no-pager 'visit-surveys*')" ]] || die 'Evaluatieverzending heeft al een geladen service; controleer eerst'
}
case "${1:-}" in
  status)
    printf 'Huidige release: %s\nVersie: ' "$CURRENT"
    cat "$CURRENT/REVISION"
    [[ ! -f "$RUN/prepared" ]] || echo 'Pakket voorbereid.'
    [[ ! -f "$RUN/activated" ]] || echo 'Pakket geactiveerd.'
    [[ ! -f "$RUN/rolled-back" ]] || echo 'Herstel uitgevoerd.'
    [[ ! -f "$RUN/automatic-rollback" ]] || echo 'Automatische terugval uitgevoerd; controleer de foutmelding.'
    if [[ "$(tr -d '\r\n' < "$CURRENT/REVISION")" == "$SHA" ]]; then "$PHP" "$PACKAGE/availability-schema.php" check "$CURRENT" "$RUN"; fi
    assert_sending_off
    ;;
  prepare)
    [[ "$(tr -d '\r\n' < "$CURRENT/REVISION")" == "$BASE" ]] || die "Live is niet de verwachte basis $BASE. Deel de uitvoer; niet forceren."
    [[ ! -e "$RUN/prepared" && ! -e "$RUN/activated" ]] || die 'Dit pakket is al voorbereid; gebruik status of activate'
    verify_package
    assert_sending_off
    systemctl is-active --quiet php8.5-fpm || die 'php8.5-fpm draait niet'
    mkdir -p "$RUN"
    printf '%s\n' "$CURRENT" > "$RUN/previous-release"
    sha256sum "$APP/shared/.env" > "$RUN/env.sha256"
    verify_env "$CURRENT"
    "$PHP" "$PACKAGE/verify.php" before "$CURRENT" "$PACKAGE"
    echo 'Basis en bestanden akkoord. Nieuwe release voorbereiden...'
    RELEASE=$(mktemp -d "$APP/releases/$(date +%Y%m%d-%H%M%S)-114ef63-XXXXXXXX")
    printf '%s\n' "$RELEASE" > "$RUN/release-dir"
    # Preserve vendor, shared symlinks and old hashed assets for already-open tabs.
    rsync -a "$CURRENT/" "$RELEASE/"
    rsync -a "$PACKAGE/payload/" "$RELEASE/"
    while IFS= read -r file; do
      chmod 644 "$RELEASE/$file"
      if [[ "$file" == *.php ]]; then "$PHP" -l "$RELEASE/$file"; fi
    done < "$PACKAGE/changed-files"
    find "$RELEASE/public/build" -type d -exec chmod 755 {} +
    find "$RELEASE/public/build" -type f -exec chmod 644 {} +
    printf '%s\n' "$SHA" > "$RELEASE/REVISION"
    basename "$RELEASE" > "$RELEASE/RELEASE"
    chown -R --no-dereference deploy:www-data "$RELEASE"
    chmod 755 "$RELEASE"
    chmod 644 "$RELEASE/REVISION" "$RELEASE/RELEASE"
    verify_env "$RELEASE"
    "$PHP" "$PACKAGE/verify.php" after "$RELEASE" "$PACKAGE"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/ProgramAvailabilityDomainTest.php"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/JsonResponseEncodingTest.php"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/RosterJointStaffOptimizerTest.php"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/RosterWeekJointXlsxTest.php"
    sudo -u www-data "$PHP" "$PACKAGE/ke-smoke.php" "$RELEASE"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/VisitSurveyMailTemplateTest.php"
    sudo -u www-data "$PHP" "$PACKAGE/smoke.php" "$RELEASE" | tee "$RUN/lesson-smoke.log"
    PREPARE_DATA=$(mktemp -d "$RUN/prepare-data.XXXXXXXX")
    "$PHP" "$PACKAGE/data-check.php" backup "$RELEASE" "$PREPARE_DATA"
    touch "$RUN/data-backed-up"
    "$PHP" "$PACKAGE/availability-schema.php" migrate "$RELEASE" "$RUN"
    sudo -u www-data "$PHP" "$PACKAGE/availability-read.php" "$RELEASE"
    sudo -u www-data "$PHP" "$PACKAGE/survey-read.php" "$RELEASE"
    sudo -u www-data "$PHP" "$PACKAGE/read-smoke.php" "$RELEASE"
    "$PHP" "$PACKAGE/data-check.php" check "$RELEASE" "$PREPARE_DATA"
    http_check before
    touch "$RUN/prepared"
    echo 'PREPARED: controles geslaagd; live staat nog op de vorige versie.'
    ;;
  activate)
    [[ -f "$RUN/prepared" && ! -f "$RUN/activated" && ! -f "$RUN/rolled-back" && ! -f "$RUN/automatic-rollback" ]] || die 'Eerst prepare; dit pakket mag niet opnieuw geactiveerd worden'
    PREVIOUS=$(cat "$RUN/previous-release")
    RELEASE=$(cat "$RUN/release-dir")
    [[ "$CURRENT" == "$PREVIOUS" ]] || die 'Live is sinds prepare gewijzigd'
    verify_package
    assert_sending_off
    verify_env "$RELEASE"
    [[ "$(tr -d '\r\n' < "$RELEASE/REVISION")" == "$SHA" ]] || die 'Onjuiste voorbereide versie'
    "$PHP" "$PACKAGE/verify.php" after "$RELEASE" "$PACKAGE"
    systemctl is-active --quiet php8.5-fpm || die 'php8.5-fpm draait niet'
    "$PHP" "$PACKAGE/availability-schema.php" check "$RELEASE" "$RUN"
    sudo -u www-data "$PHP" "$PACKAGE/availability-read.php" "$RELEASE"
    # Make a fresh read-only baseline immediately before switching; preserve changes
    # users legitimately made between prepare and activate. Never restore data.
    ACTIVATION_DATA=$(mktemp -d "$RUN/activation-data.XXXXXXXX")
    "$PHP" "$PACKAGE/data-check.php" backup "$CURRENT" "$ACTIVATION_DATA"
    # Keep rollback active through the checks and the final success marker.
    switched=0
    recover() {
      local result=$?
      trap - EXIT
      if (( result != 0 && switched == 1 )); then
        echo 'Controle mislukt: vorige release wordt hersteld.' >&2
        switch_to "$PREVIOUS"
        systemctl reload php8.5-fpm
        touch "$RUN/automatic-rollback"
      fi
      exit "$result"
    }
    trap recover EXIT
    switched=1
    switch_to "$RELEASE"
    systemctl reload php8.5-fpm
    http_check after
    python3 "$PACKAGE/survey-http.py" "$RUN"
    python3 "$PACKAGE/availability-http.py"
    sudo -u www-data "$PHP" "$PACKAGE/survey-read.php" "$RELEASE"
    assert_sending_off
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/ProgramAvailabilityDomainTest.php"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/JsonResponseEncodingTest.php"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/RosterJointStaffOptimizerTest.php"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/RosterWeekJointXlsxTest.php"
    sudo -u www-data "$PHP" "$PACKAGE/ke-smoke.php" "$RELEASE"
    sudo -u www-data "$PHP" "$RELEASE/scripts/tests/VisitSurveyMailTemplateTest.php"
    sudo -u www-data "$PHP" "$PACKAGE/smoke.php" "$RELEASE"
    sudo -u www-data "$PHP" "$PACKAGE/read-smoke.php" "$RELEASE"
    "$PHP" "$PACKAGE/data-check.php" check "$RELEASE" "$ACTIVATION_DATA"
    verify_env "$RELEASE"
    touch "$RUN/activated"
    switched=0
    echo "DEPLOY PASS $SHA - Configuratie en periodehulp live; automatische verzending UIT; bestaande aanvragen en roosters behouden."
    ;;
  rollback)
    [[ -f "$RUN/prepared" && -f "$RUN/activated" ]] || die 'Geen actieve uitrol van dit pakket gevonden'
    PREVIOUS=$(cat "$RUN/previous-release")
    RELEASE=$(cat "$RUN/release-dir")
    [[ "$CURRENT" == "$RELEASE" ]] || die 'Live is inmiddels een andere release; herstel niet forceren'
    verify_env "$PREVIOUS"
    switch_to "$PREVIOUS"
    systemctl reload php8.5-fpm
    http_check rollback
    touch "$RUN/rolled-back"
    echo "ROLLBACK PASS - terug naar $BASE; bestaande roosters behouden; nieuwe configuratietabellen en ingestelde periodes blijven bewaard. De oude code gebruikt de periodes niet."
    ;;
  *) die 'Gebruik prepare, activate, rollback of status' ;;
esac
