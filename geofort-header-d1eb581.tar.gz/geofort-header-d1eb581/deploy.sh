#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
APP=/var/www/onderwijsboeking-v2
BASE=114ef633d041467bb34331ddc9b2bfda56018eaf
SHA=d1eb581123583882d5abb8f2d449e9da46738188
RUN=/home/deploy/backups/geofort-header-d1eb581
PACKAGE=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
PHP=php8.5
die() { echo "STOP: $*" >&2; exit 1; }
[[ $EUID == 0 ]] || die 'Gebruik sudo bash deploy.sh prepare|activate|rollback|status'
command -v "$PHP" >/dev/null || die 'php8.5 ontbreekt'
exec 9>/home/deploy/.deploy-onderwijsboeking-v2.lock
flock -n 9 || die 'Er loopt al een andere uitrol'
[[ -L "$APP/current" ]] || die 'current is geen release-symlink'
CURRENT=$(readlink -f "$APP/current")
[[ "$CURRENT" == "$APP/releases/"* && -d "$CURRENT" ]] || die 'Onverwachte huidige release'

verify_package() {
  (cd "$PACKAGE" && sha256sum --quiet -c SHA256SUMS)
}
verify_env() {
  [[ "$(readlink -f "$1/.env")" == "$(readlink -f "$APP/shared/.env")" ]] || die 'De gedeelde productieconfiguratie wordt niet gebruikt'
  sha256sum --quiet -c "$RUN/env.sha256"
}
switch_to() {
  local destination=$1 holder
  [[ "$destination" == "$APP/releases/"* && -d "$destination" ]] || die 'Ongeldig releasepad'
  holder=$(mktemp -d "$APP/.switch.vi.XXXXXXXX")
  ln -s "$destination" "$holder/next"
  chown -h deploy:www-data "$holder/next"
  mv -Tf "$holder/next" "$APP/current"
  rmdir "$holder"
}
http_check() {
  local suffix=$1 path name
  for path in / /auth/login-page.php /api/getBookingProgramConfig.php; do
    name=${path//\//_}
    curl --disable --fail --silent --show-error --noproxy '*' --max-time 20 \
      --resolve onderwijsboeking.geofort.nl:443:127.0.0.1 \
      "https://onderwijsboeking.geofort.nl$path" -o "$RUN/http-$suffix-$name"
    [[ -s "$RUN/http-$suffix-$name" ]] || return 1
  done
  if [[ "$suffix" == after ]]; then
    "$PHP" "$PACKAGE/verify.php" assets "$RELEASE" "$PACKAGE" > "$RUN/assets"
    while IFS= read -r path; do
      curl --disable --fail --silent --show-error --noproxy '*' --max-time 20 \
        --resolve onderwijsboeking.geofort.nl:443:127.0.0.1 \
        "https://onderwijsboeking.geofort.nl/$path" -o "$RUN/asset-check"
      cmp "$RUN/asset-check" "$RELEASE/public/$path"
    done < "$RUN/assets"
    code=$(curl --disable --silent --show-error --noproxy '*' --max-time 20 \
      --resolve onderwijsboeking.geofort.nl:443:127.0.0.1 \
      -D "$RUN/refresh-auth-headers" -o "$RUN/refresh-auth-check" -w '%{http_code}' \
      https://onderwijsboeking.geofort.nl/api/admin/rosters/week-export.php)
    [[ "$code" == 303 ]] || return 1
    grep -iq '^location: https://onderwijsboeking.geofort.nl/auth/login-page.php' "$RUN/refresh-auth-headers" || return 1
  fi
}
read_checks() {
  local root=$1
  sudo -u www-data "$PHP" "$PACKAGE/availability-read.php" "$root"
  sudo -u www-data "$PHP" "$PACKAGE/survey-read.php" "$root"
  sudo -u www-data "$PHP" "$PACKAGE/read-smoke.php" "$root"
}
case "${1:-}" in
  status)
    printf 'Huidige release: %s\nVersie: ' "$CURRENT"
    cat "$CURRENT/REVISION"
    [[ ! -f "$RUN/prepared" ]] || echo 'Pakket voorbereid.'
    [[ ! -f "$RUN/activated" ]] || echo 'Pakket geactiveerd.'
    [[ ! -f "$RUN/rolled-back" ]] || echo 'Herstel uitgevoerd.'
    [[ ! -f "$RUN/automatic-rollback" ]] || echo 'Automatische terugval uitgevoerd; controleer het log.'
    ;;
  prepare)
    [[ "$(tr -d '\r\n' < "$CURRENT/REVISION")" == "$BASE" ]] || die "Live is niet de verwachte basis $BASE. Niet forceren."
    [[ ! -e "$RUN/prepared" && ! -e "$RUN/activated" && ! -e "$RUN/automatic-rollback" ]] || die 'Pakket heeft al een uitrolstatus; gebruik status'
    verify_package
    systemctl is-active --quiet php8.5-fpm || die 'php8.5-fpm draait niet'
    mkdir -p "$RUN"
    printf '%s\n' "$CURRENT" > "$RUN/previous-release"
    sha256sum "$APP/shared/.env" > "$RUN/env.sha256"
    verify_env "$CURRENT"
    "$PHP" "$PACKAGE/verify.php" before "$CURRENT" "$PACKAGE"
    RELEASE=$(mktemp -d "$APP/releases/$(date +%Y%m%d-%H%M%S)-header-XXXXXXXX")
    printf '%s\n' "$RELEASE" > "$RUN/release-dir"
    # Keep live dependencies, shared symlinks and old assets for already-open tabs.
    rsync -a "$CURRENT/" "$RELEASE/"
    rsync -a "$PACKAGE/payload/" "$RELEASE/"
    while IFS= read -r file; do chmod 644 "$RELEASE/$file"; done < "$PACKAGE/changed-files"
    find "$RELEASE/public/build" -type d -exec chmod 755 {} +
    find "$RELEASE/public/build" -type f -exec chmod 644 {} +
    printf '%s\n' "$SHA" > "$RELEASE/REVISION"
    basename "$RELEASE" > "$RELEASE/RELEASE"
    chown -R --no-dereference deploy:www-data "$RELEASE"
    chmod 755 "$RELEASE"
    chmod 644 "$RELEASE/REVISION" "$RELEASE/RELEASE"
    verify_env "$RELEASE"
    "$PHP" "$PACKAGE/verify.php" after "$RELEASE" "$PACKAGE"
    PREPARE_DATA=$(mktemp -d "$RUN/prepare-data.XXXXXXXX")
    "$PHP" "$PACKAGE/data-check.php" backup "$CURRENT" "$PREPARE_DATA"
    read_checks "$RELEASE"
    "$PHP" "$PACKAGE/data-check.php" check "$RELEASE" "$PREPARE_DATA"
    http_check before
    touch "$RUN/prepared"
    echo 'PREPARED: controles geslaagd; live staat nog op de vorige versie.'
    ;;
  activate)
    [[ -f "$RUN/prepared" && ! -f "$RUN/activated" && ! -f "$RUN/rolled-back" && ! -f "$RUN/automatic-rollback" ]] || die 'Eerst prepare; activeren mag slechts eenmaal'
    PREVIOUS=$(cat "$RUN/previous-release")
    RELEASE=$(cat "$RUN/release-dir")
    [[ "$CURRENT" == "$PREVIOUS" ]] || die 'Live is sinds prepare gewijzigd'
    [[ "$RELEASE" == "$APP/releases/"* && -d "$RELEASE" ]] || die 'Ongeldig voorbereidingspad'
    verify_package
    verify_env "$RELEASE"
    [[ "$(tr -d '\r\n' < "$RELEASE/REVISION")" == "$SHA" ]] || die 'Onjuiste voorbereide versie'
    "$PHP" "$PACKAGE/verify.php" after "$RELEASE" "$PACKAGE"
    systemctl is-active --quiet php8.5-fpm || die 'php8.5-fpm draait niet'
    ACTIVATION_DATA=$(mktemp -d "$RUN/activation-data.XXXXXXXX")
    "$PHP" "$PACKAGE/data-check.php" backup "$CURRENT" "$ACTIVATION_DATA"
    switched=0
    recover() {
      local result=$?
      trap - EXIT
      if (( result != 0 && switched == 1 )); then
        echo 'Controle mislukt: vorige release wordt hersteld.' >&2
        switch_to "$PREVIOUS"
        systemctl reload php8.5-fpm
        touch "$RUN/automatic-rollback"
      fi
      exit "$result"
    }
    trap recover EXIT
    switched=1
    switch_to "$RELEASE"
    systemctl reload php8.5-fpm
    http_check after
    python3 "$PACKAGE/availability-http.py"
    read_checks "$RELEASE"
    "$PHP" "$PACKAGE/data-check.php" check "$RELEASE" "$ACTIVATION_DATA"
    verify_env "$RELEASE"
    touch "$RUN/activated"
    switched=0
    echo "DEPLOY PASS $SHA - dashboarduitlijning live; bestaande aanvragen, roosters en configuratie behouden; geen mail verstuurd of mailtaak gestart."
    ;;
  rollback)
    [[ -f "$RUN/prepared" && -f "$RUN/activated" && ! -f "$RUN/rolled-back" ]] || die 'Geen actieve uitrol van dit pakket gevonden'
    PREVIOUS=$(cat "$RUN/previous-release")
    RELEASE=$(cat "$RUN/release-dir")
    [[ "$CURRENT" == "$RELEASE" ]] || die 'Live is inmiddels een andere release; herstel niet forceren'
    verify_env "$PREVIOUS"
    switch_to "$PREVIOUS"
    systemctl reload php8.5-fpm
    http_check rollback
    touch "$RUN/rolled-back"
    echo "ROLLBACK PASS - terug naar $BASE; alle bestaande gegevens en configuratie behouden."
    ;;
  *) die 'Gebruik prepare, activate, rollback of status' ;;
esac
