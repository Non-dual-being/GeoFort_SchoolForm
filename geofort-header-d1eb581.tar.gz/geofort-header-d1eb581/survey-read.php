<?php
declare(strict_types=1);
ini_set('zend.exception_ignore_args', '1');

function checkReleaseSurveyReports(PDO $pdo): array
{
    $pdo->exec('SET SESSION TRANSACTION READ ONLY');
    $repository = new GeoFort\Services\Sql\VisitSurveySqlRepository($pdo);
    $service = new GeoFort\Services\Survey\VisitSurveyService($repository);
    $expected = $repository->settings();
    if ($expected['delayDays'] < 1 || $expected['delayDays'] > 30
        || ($expected['enabled'] && $expected['startDate'] === null)) {
        throw new RuntimeException('Invalid existing survey settings; inspect without changing them');
    }
    if ($expected['startDate'] !== null) GeoFort\Services\Survey\VisitSurveyPolicy::date($expected['startDate']);
    $now = new DateTimeImmutable('now', new DateTimeZone('Europe/Amsterdam'));
    foreach (['all','day-four','day-five','morning'] as $variant) {
        $report = $service->report(['variant' => $variant], $now);
        if ($report['settings'] !== $expected) throw new RuntimeException('Survey settings changed during read-only checks');
    }
    if ($repository->settings() !== $expected) throw new RuntimeException('Survey settings changed during read-only checks');
    echo 'SURVEY READ PASS - dashboard filters load; existing setting '.($expected['enabled'] ? 'ON' : 'OFF')
        .', delay '.$expected['delayDays'].' days, start '.($expected['startDate'] ?? 'unset')
        ." retained; no writes or mail\n";
    return $expected;
}

if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    $container = require $argv[1].'/bootstrap.php';
    checkReleaseSurveyReports($container['db'][GeoFort\Database\Connector::class]);
}
